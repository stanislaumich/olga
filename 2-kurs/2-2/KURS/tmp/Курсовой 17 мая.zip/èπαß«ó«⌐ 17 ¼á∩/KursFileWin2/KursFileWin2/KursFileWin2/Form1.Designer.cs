﻿namespace KursFileWin2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bLoad = new System.Windows.Forms.Button();
            this.bSave = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataTovar = new System.Windows.Forms.DataGridView();
            this.SKU = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NUM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PRICE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.bDel = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataVsp = new System.Windows.Forms.DataGridView();
            this.SKU1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NAME1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NUM1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PRICE1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bOut = new System.Windows.Forms.Button();
            this.bIn = new System.Windows.Forms.Button();
            this.bFile = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.bUp = new System.Windows.Forms.Button();
            this.bDo = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lSum = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataTovar)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataVsp)).BeginInit();
            this.SuspendLayout();
            // 
            // bLoad
            // 
            this.bLoad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bLoad.Location = new System.Drawing.Point(696, 12);
            this.bLoad.Name = "bLoad";
            this.bLoad.Size = new System.Drawing.Size(108, 21);
            this.bLoad.TabIndex = 0;
            this.bLoad.Text = "Загрузить";
            this.bLoad.UseVisualStyleBackColor = true;
            this.bLoad.Click += new System.EventHandler(this.bLoad_Click);
            // 
            // bSave
            // 
            this.bSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bSave.Location = new System.Drawing.Point(696, 41);
            this.bSave.Name = "bSave";
            this.bSave.Size = new System.Drawing.Size(108, 21);
            this.bSave.TabIndex = 1;
            this.bSave.Text = "Сохранить";
            this.bSave.UseVisualStyleBackColor = true;
            this.bSave.Click += new System.EventHandler(this.bSave_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataTovar);
            this.groupBox1.Location = new System.Drawing.Point(4, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(686, 217);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Товар в магазине";
            // 
            // dataTovar
            // 
            this.dataTovar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataTovar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SKU,
            this.NAME,
            this.NUM,
            this.PRICE});
            this.dataTovar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataTovar.Location = new System.Drawing.Point(3, 16);
            this.dataTovar.Name = "dataTovar";
            this.dataTovar.Size = new System.Drawing.Size(680, 198);
            this.dataTovar.TabIndex = 0;
            // 
            // SKU
            // 
            this.SKU.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.SKU.HeaderText = "SKU";
            this.SKU.Name = "SKU";
            this.SKU.Width = 54;
            // 
            // NAME
            // 
            this.NAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.NAME.HeaderText = "NAME";
            this.NAME.Name = "NAME";
            this.NAME.Width = 63;
            // 
            // NUM
            // 
            this.NUM.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.NUM.HeaderText = "NUM";
            this.NUM.Name = "NUM";
            this.NUM.Width = 57;
            // 
            // PRICE
            // 
            this.PRICE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.PRICE.HeaderText = "PRICE";
            this.PRICE.Name = "PRICE";
            this.PRICE.Width = 64;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgressBar1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 460);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(806, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 16);
            // 
            // bDel
            // 
            this.bDel.Location = new System.Drawing.Point(696, 83);
            this.bDel.Name = "bDel";
            this.bDel.Size = new System.Drawing.Size(105, 22);
            this.bDel.TabIndex = 5;
            this.bDel.Text = "Удалить";
            this.bDel.UseVisualStyleBackColor = true;
            this.bDel.Click += new System.EventHandler(this.bDel_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataVsp);
            this.groupBox2.Location = new System.Drawing.Point(4, 255);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(683, 196);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Отобраный товар";
            // 
            // dataVsp
            // 
            this.dataVsp.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataVsp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataVsp.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SKU1,
            this.NAME1,
            this.NUM1,
            this.PRICE1});
            this.dataVsp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataVsp.Location = new System.Drawing.Point(3, 16);
            this.dataVsp.Name = "dataVsp";
            this.dataVsp.Size = new System.Drawing.Size(677, 177);
            this.dataVsp.TabIndex = 0;
            this.dataVsp.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataVsp_CellContentClick);
            // 
            // SKU1
            // 
            this.SKU1.HeaderText = "SKU";
            this.SKU1.Name = "SKU1";
            this.SKU1.Width = 54;
            // 
            // NAME1
            // 
            this.NAME1.HeaderText = "NAME";
            this.NAME1.Name = "NAME1";
            this.NAME1.Width = 63;
            // 
            // NUM1
            // 
            this.NUM1.HeaderText = "NUM";
            this.NUM1.Name = "NUM1";
            this.NUM1.Width = 57;
            // 
            // PRICE1
            // 
            this.PRICE1.HeaderText = "PRICE";
            this.PRICE1.Name = "PRICE1";
            this.PRICE1.Width = 64;
            // 
            // bOut
            // 
            this.bOut.Location = new System.Drawing.Point(7, 457);
            this.bOut.Name = "bOut";
            this.bOut.Size = new System.Drawing.Size(201, 23);
            this.bOut.TabIndex = 7;
            this.bOut.Text = "Оформить продажу списка товаров";
            this.bOut.UseVisualStyleBackColor = true;
            this.bOut.Click += new System.EventHandler(this.bOut_Click);
            // 
            // bIn
            // 
            this.bIn.Location = new System.Drawing.Point(215, 457);
            this.bIn.Name = "bIn";
            this.bIn.Size = new System.Drawing.Size(196, 23);
            this.bIn.TabIndex = 8;
            this.bIn.Text = "Оформить приход списка товаров";
            this.bIn.UseVisualStyleBackColor = true;
            this.bIn.Click += new System.EventHandler(this.bIn_Click);
            // 
            // bFile
            // 
            this.bFile.Location = new System.Drawing.Point(696, 271);
            this.bFile.Name = "bFile";
            this.bFile.Size = new System.Drawing.Size(105, 22);
            this.bFile.TabIndex = 9;
            this.bFile.Text = "Выбрать файл";
            this.bFile.UseVisualStyleBackColor = true;
            this.bFile.Click += new System.EventHandler(this.bFile_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // bUp
            // 
            this.bUp.Location = new System.Drawing.Point(71, 222);
            this.bUp.Name = "bUp";
            this.bUp.Size = new System.Drawing.Size(61, 27);
            this.bUp.TabIndex = 10;
            this.bUp.Text = "Del";
            this.bUp.UseVisualStyleBackColor = true;
            this.bUp.Click += new System.EventHandler(this.bUp_Click);
            // 
            // bDo
            // 
            this.bDo.Location = new System.Drawing.Point(4, 222);
            this.bDo.Name = "bDo";
            this.bDo.Size = new System.Drawing.Size(61, 27);
            this.bDo.TabIndex = 11;
            this.bDo.Text = "Add";
            this.bDo.UseVisualStyleBackColor = true;
            this.bDo.Click += new System.EventHandler(this.bDo_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(200, 229);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Сумма:";
            // 
            // lSum
            // 
            this.lSum.AutoSize = true;
            this.lSum.Location = new System.Drawing.Point(250, 229);
            this.lSum.Name = "lSum";
            this.lSum.Size = new System.Drawing.Size(13, 13);
            this.lSum.TabIndex = 13;
            this.lSum.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(806, 482);
            this.Controls.Add(this.lSum);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bDo);
            this.Controls.Add(this.bUp);
            this.Controls.Add(this.bFile);
            this.Controls.Add(this.bIn);
            this.Controls.Add(this.bOut);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.bDel);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.bSave);
            this.Controls.Add(this.bLoad);
            this.Name = "Form1";
            this.Text = "Магазин автозапчастей";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataTovar)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataVsp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bLoad;
        private System.Windows.Forms.Button bSave;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.DataGridView dataTovar;
        private System.Windows.Forms.DataGridViewTextBoxColumn SKU;
        private System.Windows.Forms.DataGridViewTextBoxColumn NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn NUM;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRICE;
        private System.Windows.Forms.Button bDel;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataVsp;
        private System.Windows.Forms.DataGridViewTextBoxColumn SKU1;
        private System.Windows.Forms.DataGridViewTextBoxColumn NAME1;
        private System.Windows.Forms.DataGridViewTextBoxColumn NUM1;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRICE1;
        private System.Windows.Forms.Button bOut;
        private System.Windows.Forms.Button bIn;
        private System.Windows.Forms.Button bFile;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button bUp;
        private System.Windows.Forms.Button bDo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lSum;
    }
}


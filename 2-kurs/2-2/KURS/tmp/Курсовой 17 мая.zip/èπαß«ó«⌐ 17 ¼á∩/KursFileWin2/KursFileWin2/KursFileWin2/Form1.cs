﻿using System;
using System.IO;
using System.Windows.Forms;
namespace KursFileWin2
{
    struct Tovar
    {
        public string sku;
        public string name;
        public int num;
        public double price;

        public Tovar(string n, string c, int a, double p)
        {
            sku = n;
            name = c;
            num = a;
            price = p;
        }
    }



    public partial class Form1 : Form
    {
       
        static string pathshop = "shop.dat";
        static string pathvsp = "shopprod.dat";

        public Form1()
        {
            InitializeComponent();
            loadfile(dataTovar, pathshop);// автозагрузка магазина при старте
            loadfile(dataVsp, pathvsp);
        }

        public void loadfile(DataGridView dt,string fn)
    {// вспомогательная загрузка из файла
        using (BinaryReader reader = new BinaryReader(File.Open(fn, FileMode.Open)))
        {
            //int i = 0;
            while (reader.PeekChar() > -1)
            {
                string sku = reader.ReadString();
                string name = reader.ReadString();

                string num1 = reader.ReadString();
                int num = Convert.ToInt32(num1);

                string price1 = reader.ReadString();
                price1 = price1.Replace('.', ',');
                double price = Convert.ToDouble(price1);

                
                string[] row0 = { sku, name, num.ToString("F0"), 
                        price.ToString("F2")};
                dt.Rows.Add(row0);

            }
        }
    }

        public void savefile(DataGridView dt, string fn)
        {// вспомогательное сохранение в файл
            using (BinaryWriter writer = new BinaryWriter(File.Open(fn, FileMode.Create)))
            {
                for (int i = 0; i < dt.RowCount - 1; i++)
                {
                    string st;
                    for (int j = 0; j < 4; j++)
                    {
                        st = dt.Rows[i].Cells[j].Value.ToString();
                        writer.Write(st);
                    }
                }
            }
        }

        private void bLoad_Click(object sender, EventArgs e)
        {// загружаем состояние магазина
            loadfile(dataTovar, pathshop);            
        }

        private void bSave_Click(object sender, EventArgs e)
        {// сохраняем состояние магазина
            if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                savefile(dataTovar, saveFileDialog1.FileName);
            }
        }

        private void bDel_Click(object sender, EventArgs e)
        {// удаляем товар без списания продажей из магазина
            if (dataTovar.SelectedRows.Count > 0 &&
            dataTovar.SelectedRows[0].Index !=
            dataTovar.Rows.Count - 1)
            {
                dataTovar.Rows.RemoveAt(
                    dataTovar.SelectedRows[0].Index);
            }
        }

        private void bFile_Click(object sender, EventArgs e)
        {// загружаем таблицу продаж из файла временного хранения
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                loadfile(dataVsp, openFileDialog1.FileName);  
                
            }
        }

        private string getVspsum()
         {//подсчет суммы всего чека продажи
                 double sum = 0.0;
                for (int i = 0; i < dataVsp.RowCount - 1; i++)
                {
                    string stn;
                    string stp;

                    stp = dataVsp.Rows[i].Cells[3].Value.ToString();
                    stn = dataVsp.Rows[i].Cells[2].Value.ToString();
                    sum = sum + Convert.ToDouble(stn) * Convert.ToDouble(stp);
                    
                }
                return  sum.ToString("F2"); 
             }

        private static DialogResult ShowInputDialog(ref string input)
        {
            System.Drawing.Size size = new System.Drawing.Size(200, 70);
            Form inputBox = new Form();

            inputBox.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            inputBox.ClientSize = size;
            inputBox.Text = "Name";

            System.Windows.Forms.TextBox textBox = new TextBox();
            textBox.Size = new System.Drawing.Size(size.Width - 10, 23);
            textBox.Location = new System.Drawing.Point(5, 5);
            textBox.Text = input;
            inputBox.Controls.Add(textBox);

            Button okButton = new Button();
            okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            okButton.Name = "okButton";
            okButton.Size = new System.Drawing.Size(75, 23);
            okButton.Text = "&OK";
            okButton.Location = new System.Drawing.Point(size.Width - 80 - 80, 39);
            inputBox.Controls.Add(okButton);

            Button cancelButton = new Button();
            cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            cancelButton.Name = "cancelButton";
            cancelButton.Size = new System.Drawing.Size(75, 23);
            cancelButton.Text = "&Cancel";
            cancelButton.Location = new System.Drawing.Point(size.Width - 80, 39);
            inputBox.Controls.Add(cancelButton);

            inputBox.AcceptButton = okButton;
            inputBox.CancelButton = cancelButton;

            DialogResult result = inputBox.ShowDialog();
            input = textBox.Text;
            return result;
        }

        private void bDo_Click(object sender, EventArgs e)
        {// подготавливаем продажный чек с вычитанием товаров на складе
            int err = 0;
            if (dataTovar.SelectedRows.Count > 0 &&
                dataTovar.SelectedRows[0].Index !=
                dataTovar.Rows.Count - 1)
            {
                DataGridViewRow row = (DataGridViewRow)dataTovar.Rows[0].Clone();
                int intColIndex = 0;
                foreach (DataGridViewCell cell in dataTovar.Rows[dataTovar.SelectedRows[0].Index].Cells)
                {
                    if (intColIndex==2)
                    {
                        string input = "Укажите количество единиц товара";
                        ShowInputDialog(ref input);
                        int f =Convert.ToInt32(dataTovar.Rows[dataTovar.SelectedRows[0].Index].Cells[intColIndex].Value);
                        f = f - Convert.ToInt32(input);
                        if (f < 0) { err = 1; break; }
                        dataTovar.Rows[dataTovar.SelectedRows[0].Index].Cells[intColIndex].Value = f.ToString();
                        row.Cells[intColIndex].Value = input;
                    }
                    else{
                     row.Cells[intColIndex].Value = cell.Value;   
                    }
                    intColIndex++;
                }
                if (err==0)
                {
                    dataVsp.Rows.Add(row);
                    lSum.Text = getVspsum();
                }
            }
        }

        private void dataVsp_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {// пересчитываем сумму чека
            lSum.Text = getVspsum();
        }

        private void bUp_Click(object sender, EventArgs e)
        {// тут удаляем товар из продаж и добавляем его назад в кол-во товаров в магазине

            string tsku=dataVsp.SelectedRows[0].Cells[0].Value.ToString();

            for (int i = 0; i < dataTovar.RowCount - 1; i++)
            {
                if (tsku == dataTovar.Rows[i].Cells[0].Value.ToString())
                {
                    string st = dataTovar.Rows[i].Cells[2].Value.ToString();
                    int tz = Convert.ToInt32(st) + Convert.ToInt32(dataVsp.SelectedRows[0].Cells[2].Value.ToString());
                    st = tz.ToString();
                    dataTovar.Rows[i].Cells[2].Value = st;
                }   
            }
            
            
            
            if (dataVsp.SelectedRows.Count > 0 &&
            dataVsp.SelectedRows[0].Index !=
            dataVsp.Rows.Count - 1)
            {
                dataVsp.Rows.RemoveAt(dataVsp.SelectedRows[0].Index);
            }
            lSum.Text = getVspsum();
        }
       
        private void bIn_Click(object sender, EventArgs e)
        {   // тут мы по файлу прихода добавляем товар на склад
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                loadfile(dataVsp, openFileDialog1.FileName);
                //*******************
               // dataVsp.SelectAll();
               // dataVsp.SelectedRows.   
                for (int d = 0; d < dataVsp.Rows.Count - 1; d++)
                {
                    
                    string tsku = dataVsp.Rows[d].Cells[0].Value.ToString();

                    for (int i = 0; i < dataTovar.RowCount - 1; i++)
                    
                        if (tsku == dataTovar.Rows[i].Cells[0].Value.ToString())
                        {
                            string st = dataTovar.Rows[i].Cells[2].Value.ToString();
                            int tz = Convert.ToInt32(st) + Convert.ToInt32(dataVsp.Rows[d].Cells[2].Value.ToString());
                            st = tz.ToString();
                            dataTovar.Rows[i].Cells[2].Value = st;
                        }
                    }
                    if (dataVsp.SelectedRows.Count > 0 &&
                    dataVsp.SelectedRows[0].Index !=
                    dataVsp.Rows.Count - 1)
                    {
                        dataVsp.Rows.RemoveAt(dataVsp.SelectedRows[0].Index);
                    }
                    lSum.Text = getVspsum();
                    
                   
                }


                //*******************

                dataVsp.Rows.Clear();                
            }
        //}

        private void bOut_Click(object sender, EventArgs e)
        { // тут мы сохраняем продажу в файл для истории продаж
            if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                savefile(dataVsp, saveFileDialog1.FileName);
                dataVsp.Rows.Clear();

            }
            
            
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            savefile(dataTovar, pathshop);
            savefile(dataVsp, pathvsp);
        }

        private void dataVsp_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

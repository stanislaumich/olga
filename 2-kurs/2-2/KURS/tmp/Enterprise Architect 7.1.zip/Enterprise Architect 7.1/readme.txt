After the installation copy file key.dat to the folder where Enterprise Architect is located 
(e.g. C:\Program Files\Sparx Systems\EA\)

Alternate way to set up registration key:
- Select Help -> Register and Manage License Key(s)
- press button "Add Key"
- Enter private key:
    Name: Software Architect
    Company: EPAM Systems
    Key: {ADF8D83B-0683-4d1f-BB60-FF66D-WFM1-CHPZ-PII0-HN75-BC}

Note: enter serial number with curly brackets!

﻿
namespace KONTRAGENT
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.ZdogBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.z1DataSet = new KONTRAGENT.Z1DataSet();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.fioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adrDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iddolg1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kONTRPEOPLEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kONTRBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.date_b = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.date_e = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datebDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idkontrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kONTRDOGOVORBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.nazvDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uadrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.padrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.schet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.filial = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bANKKONTRBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.nazvDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adrDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.schetDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.filialDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dopDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bANKBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.nazvDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingDOLG = new System.Windows.Forms.BindingSource(this.components);
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.button15 = new System.Windows.Forms.Button();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.fioDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adrDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iddolg1DataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idkontrDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nazv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pEOPLEBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button16 = new System.Windows.Forms.Button();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.unnDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nazvDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uadrDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.padrDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.b = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.bANKBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dataGridView10 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nazvDataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sTATUSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button18 = new System.Windows.Forms.Button();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.dataGridView9 = new System.Windows.Forms.DataGridView();
            this.dOGOVORBindingSourcedogovor = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.pEOPLEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.dataGridView13 = new System.Windows.Forms.DataGridView();
            this.fioDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pEOPLEBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.dataGridView12 = new System.Windows.Forms.DataGridView();
            this.nomerDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datebDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateeDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idkontrDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idpeopleDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.dataGridView11 = new System.Windows.Forms.DataGridView();
            this.unnDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nazvDataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uadrDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.padrDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.reportViewer2 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.pEOPLEDOLGBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dOGOVORBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bANKKONTRBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kONTRTableAdapter = new KONTRAGENT.Z1DataSetTableAdapters.KONTRTableAdapter();
            this.bANKTableAdapter = new KONTRAGENT.Z1DataSetTableAdapters.BANKTableAdapter();
            this.pEOPLETableAdapter = new KONTRAGENT.Z1DataSetTableAdapters.PEOPLETableAdapter();
            this.dOGOVORTableAdapter = new KONTRAGENT.Z1DataSetTableAdapters.DOGOVORTableAdapter();
            this.dOLGTableAdapter = new KONTRAGENT.Z1DataSetTableAdapters.DOLGTableAdapter();
            this.sTATUSTableAdapter = new KONTRAGENT.Z1DataSetTableAdapters.STATUSTableAdapter();
            this.helpProvider1 = new System.Windows.Forms.HelpProvider();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.фАЙЛToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вЫХОДToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.помощьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ZdogTableAdapter = new KONTRAGENT.Z1DataSetTableAdapters.ZdogTableAdapter();
            this.nomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.НАЧАЛО = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.ZdogBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.z1DataSet)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kONTRPEOPLEBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kONTRBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kONTRDOGOVORBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bANKKONTRBindingSource1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bANKBindingSource)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingDOLG)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pEOPLEBindingSource1)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bANKBindingSource1)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTATUSBindingSource)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dOGOVORBindingSourcedogovor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pEOPLEBindingSource)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pEOPLEBindingSource2)).BeginInit();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView12)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pEOPLEDOLGBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dOGOVORBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bANKKONTRBindingSource)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ZdogBindingSource
            // 
            this.ZdogBindingSource.DataMember = "Zdog";
            this.ZdogBindingSource.DataSource = this.z1DataSet;
            // 
            // z1DataSet
            // 
            this.z1DataSet.DataSetName = "Z1DataSet";
            this.z1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 24);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1078, 755);
            this.tabControl1.TabIndex = 11;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1070, 729);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Сводная";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView4);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.dataGridView3);
            this.groupBox1.Controls.Add(this.dataGridView2);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1064, 723);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Справочник контрагентов ";
            // 
            // dataGridView4
            // 
            this.dataGridView4.AllowUserToAddRows = false;
            this.dataGridView4.AllowUserToOrderColumns = true;
            this.dataGridView4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.fioDataGridViewTextBoxColumn,
            this.phoneDataGridViewTextBoxColumn,
            this.adrDataGridViewTextBoxColumn1,
            this.iddolg1DataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.kONTRPEOPLEBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(0, 334);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(1056, 110);
            this.dataGridView4.TabIndex = 18;
            // 
            // fioDataGridViewTextBoxColumn
            // 
            this.fioDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.fioDataGridViewTextBoxColumn.DataPropertyName = "fio";
            this.fioDataGridViewTextBoxColumn.HeaderText = "ФИО";
            this.fioDataGridViewTextBoxColumn.Name = "fioDataGridViewTextBoxColumn";
            this.fioDataGridViewTextBoxColumn.Width = 59;
            // 
            // phoneDataGridViewTextBoxColumn
            // 
            this.phoneDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.phoneDataGridViewTextBoxColumn.DataPropertyName = "phone";
            this.phoneDataGridViewTextBoxColumn.HeaderText = "ТЕЛЕФОН";
            this.phoneDataGridViewTextBoxColumn.Name = "phoneDataGridViewTextBoxColumn";
            this.phoneDataGridViewTextBoxColumn.Width = 88;
            // 
            // adrDataGridViewTextBoxColumn1
            // 
            this.adrDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.adrDataGridViewTextBoxColumn1.DataPropertyName = "adr";
            this.adrDataGridViewTextBoxColumn1.HeaderText = "АДРЕС";
            this.adrDataGridViewTextBoxColumn1.Name = "adrDataGridViewTextBoxColumn1";
            this.adrDataGridViewTextBoxColumn1.Width = 69;
            // 
            // iddolg1DataGridViewTextBoxColumn
            // 
            this.iddolg1DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.iddolg1DataGridViewTextBoxColumn.DataPropertyName = "id_dolg1";
            this.iddolg1DataGridViewTextBoxColumn.HeaderText = "ДОЛЖНОСТЬ";
            this.iddolg1DataGridViewTextBoxColumn.Name = "iddolg1DataGridViewTextBoxColumn";
            this.iddolg1DataGridViewTextBoxColumn.Width = 105;
            // 
            // kONTRPEOPLEBindingSource
            // 
            this.kONTRPEOPLEBindingSource.DataMember = "KONTRPEOPLE";
            this.kONTRPEOPLEBindingSource.DataSource = this.kONTRBindingSource;
            // 
            // kONTRBindingSource
            // 
            this.kONTRBindingSource.DataMember = "KONTR";
            this.kONTRBindingSource.DataSource = this.z1DataSet;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(2, 318);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Сотрудники";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 447);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Договоры";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 206);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "Банки";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Контрагенты";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToOrderColumns = true;
            this.dataGridView3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.date_b,
            this.date_e,
            this.nomerDataGridViewTextBoxColumn,
            this.datebDataGridViewTextBoxColumn,
            this.dateeDataGridViewTextBoxColumn,
            this.idDataGridViewTextBoxColumn2,
            this.idkontrDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.kONTRDOGOVORBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(0, 463);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(1056, 254);
            this.dataGridView3.TabIndex = 13;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "nomer";
            this.Column1.HeaderText = "НОМЕР";
            this.Column1.Name = "Column1";
            // 
            // date_b
            // 
            this.date_b.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.date_b.DataPropertyName = "date_b";
            this.date_b.HeaderText = "НАЧАЛО";
            this.date_b.Name = "date_b";
            this.date_b.Width = 78;
            // 
            // date_e
            // 
            this.date_e.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.date_e.DataPropertyName = "date_e";
            this.date_e.HeaderText = "КОНЕЦ";
            this.date_e.Name = "date_e";
            this.date_e.Width = 70;
            // 
            // nomerDataGridViewTextBoxColumn
            // 
            this.nomerDataGridViewTextBoxColumn.DataPropertyName = "nomer";
            this.nomerDataGridViewTextBoxColumn.HeaderText = "nomer";
            this.nomerDataGridViewTextBoxColumn.Name = "nomerDataGridViewTextBoxColumn";
            // 
            // datebDataGridViewTextBoxColumn
            // 
            this.datebDataGridViewTextBoxColumn.DataPropertyName = "date_b";
            this.datebDataGridViewTextBoxColumn.HeaderText = "date_b";
            this.datebDataGridViewTextBoxColumn.Name = "datebDataGridViewTextBoxColumn";
            // 
            // dateeDataGridViewTextBoxColumn
            // 
            this.dateeDataGridViewTextBoxColumn.DataPropertyName = "date_e";
            this.dateeDataGridViewTextBoxColumn.HeaderText = "date_e";
            this.dateeDataGridViewTextBoxColumn.Name = "dateeDataGridViewTextBoxColumn";
            // 
            // idDataGridViewTextBoxColumn2
            // 
            this.idDataGridViewTextBoxColumn2.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn2.HeaderText = "id";
            this.idDataGridViewTextBoxColumn2.Name = "idDataGridViewTextBoxColumn2";
            // 
            // idkontrDataGridViewTextBoxColumn
            // 
            this.idkontrDataGridViewTextBoxColumn.DataPropertyName = "id_kontr";
            this.idkontrDataGridViewTextBoxColumn.HeaderText = "id_kontr";
            this.idkontrDataGridViewTextBoxColumn.Name = "idkontrDataGridViewTextBoxColumn";
            // 
            // kONTRDOGOVORBindingSource
            // 
            this.kONTRDOGOVORBindingSource.DataMember = "KONTRDOGOVOR";
            this.kONTRDOGOVORBindingSource.DataSource = this.kONTRBindingSource;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nazvDataGridViewTextBoxColumn,
            this.uadrDataGridViewTextBoxColumn,
            this.padrDataGridViewTextBoxColumn,
            this.unnDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.kONTRBindingSource;
            this.dataGridView2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
            this.dataGridView2.Location = new System.Drawing.Point(0, 35);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(1056, 168);
            this.dataGridView2.TabIndex = 12;
            // 
            // nazvDataGridViewTextBoxColumn
            // 
            this.nazvDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.nazvDataGridViewTextBoxColumn.DataPropertyName = "nazv";
            this.nazvDataGridViewTextBoxColumn.HeaderText = "НАЗВАНИЕ";
            this.nazvDataGridViewTextBoxColumn.Name = "nazvDataGridViewTextBoxColumn";
            this.nazvDataGridViewTextBoxColumn.ReadOnly = true;
            this.nazvDataGridViewTextBoxColumn.Width = 91;
            // 
            // uadrDataGridViewTextBoxColumn
            // 
            this.uadrDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.uadrDataGridViewTextBoxColumn.DataPropertyName = "uadr";
            this.uadrDataGridViewTextBoxColumn.HeaderText = "ЮР. АДРЕС";
            this.uadrDataGridViewTextBoxColumn.Name = "uadrDataGridViewTextBoxColumn";
            this.uadrDataGridViewTextBoxColumn.ReadOnly = true;
            this.uadrDataGridViewTextBoxColumn.Width = 84;
            // 
            // padrDataGridViewTextBoxColumn
            // 
            this.padrDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.padrDataGridViewTextBoxColumn.DataPropertyName = "padr";
            this.padrDataGridViewTextBoxColumn.HeaderText = "ПОЧТ. АДРЕС";
            this.padrDataGridViewTextBoxColumn.Name = "padrDataGridViewTextBoxColumn";
            this.padrDataGridViewTextBoxColumn.ReadOnly = true;
            this.padrDataGridViewTextBoxColumn.Width = 97;
            // 
            // unnDataGridViewTextBoxColumn
            // 
            this.unnDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.unnDataGridViewTextBoxColumn.DataPropertyName = "unn";
            this.unnDataGridViewTextBoxColumn.HeaderText = "УНП";
            this.unnDataGridViewTextBoxColumn.Name = "unnDataGridViewTextBoxColumn";
            this.unnDataGridViewTextBoxColumn.ReadOnly = true;
            this.unnDataGridViewTextBoxColumn.Width = 56;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.schet,
            this.filial,
            this.adr,
            this.idDataGridViewTextBoxColumn1});
            this.dataGridView1.DataSource = this.bANKKONTRBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(0, 222);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1056, 93);
            this.dataGridView1.TabIndex = 11;
            // 
            // schet
            // 
            this.schet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.schet.DataPropertyName = "schet";
            this.schet.HeaderText = "СЧЕТ";
            this.schet.Name = "schet";
            this.schet.Width = 61;
            // 
            // filial
            // 
            this.filial.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.filial.DataPropertyName = "filial";
            this.filial.HeaderText = "ФИЛИАЛ";
            this.filial.Name = "filial";
            this.filial.Width = 82;
            // 
            // adr
            // 
            this.adr.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.adr.DataPropertyName = "adr";
            this.adr.HeaderText = "АДРЕС";
            this.adr.Name = "adr";
            this.adr.Width = 69;
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "id";
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            // 
            // bANKKONTRBindingSource1
            // 
            this.bANKKONTRBindingSource1.DataMember = "BANKKONTR";
            this.bANKKONTRBindingSource1.DataSource = this.kONTRBindingSource;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1070, 729);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Банки";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox3.Controls.Add(this.textBox17);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.button14);
            this.groupBox3.Controls.Add(this.dataGridView6);
            this.groupBox3.Controls.Add(this.button5);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.textBox9);
            this.groupBox3.Controls.Add(this.textBox8);
            this.groupBox3.Controls.Add(this.textBox7);
            this.groupBox3.Controls.Add(this.textBox6);
            this.groupBox3.Controls.Add(this.textBox5);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(759, 739);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Банки";
            // 
            // textBox17
            // 
            this.textBox17.Enabled = false;
            this.textBox17.Location = new System.Drawing.Point(646, 46);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(100, 20);
            this.textBox17.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(622, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "ID";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(215, 162);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(105, 22);
            this.button14.TabIndex = 13;
            this.button14.Text = "Удалить запись";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // dataGridView6
            // 
            this.dataGridView6.AllowUserToAddRows = false;
            this.dataGridView6.AllowUserToDeleteRows = false;
            this.dataGridView6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView6.AutoGenerateColumns = false;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nazvDataGridViewTextBoxColumn4,
            this.adrDataGridViewTextBoxColumn3,
            this.schetDataGridViewTextBoxColumn1,
            this.filialDataGridViewTextBoxColumn1,
            this.dopDataGridViewTextBoxColumn2,
            this.Column2});
            this.dataGridView6.DataSource = this.bANKBindingSource;
            this.dataGridView6.Location = new System.Drawing.Point(6, 201);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.Size = new System.Drawing.Size(740, 532);
            this.dataGridView6.TabIndex = 12;
            this.dataGridView6.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView6_CellContentClick);
            this.dataGridView6.Click += new System.EventHandler(this.dataGridView6_Click);
            // 
            // nazvDataGridViewTextBoxColumn4
            // 
            this.nazvDataGridViewTextBoxColumn4.DataPropertyName = "nazv";
            this.nazvDataGridViewTextBoxColumn4.HeaderText = "Название";
            this.nazvDataGridViewTextBoxColumn4.Name = "nazvDataGridViewTextBoxColumn4";
            // 
            // adrDataGridViewTextBoxColumn3
            // 
            this.adrDataGridViewTextBoxColumn3.DataPropertyName = "adr";
            this.adrDataGridViewTextBoxColumn3.HeaderText = "Адрес";
            this.adrDataGridViewTextBoxColumn3.Name = "adrDataGridViewTextBoxColumn3";
            // 
            // schetDataGridViewTextBoxColumn1
            // 
            this.schetDataGridViewTextBoxColumn1.DataPropertyName = "schet";
            this.schetDataGridViewTextBoxColumn1.HeaderText = "Счет";
            this.schetDataGridViewTextBoxColumn1.Name = "schetDataGridViewTextBoxColumn1";
            // 
            // filialDataGridViewTextBoxColumn1
            // 
            this.filialDataGridViewTextBoxColumn1.DataPropertyName = "filial";
            this.filialDataGridViewTextBoxColumn1.HeaderText = "Филиал";
            this.filialDataGridViewTextBoxColumn1.Name = "filialDataGridViewTextBoxColumn1";
            // 
            // dopDataGridViewTextBoxColumn2
            // 
            this.dopDataGridViewTextBoxColumn2.DataPropertyName = "dop";
            this.dopDataGridViewTextBoxColumn2.HeaderText = "Дополнительно";
            this.dopDataGridViewTextBoxColumn2.Name = "dopDataGridViewTextBoxColumn2";
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "id";
            this.Column2.HeaderText = "ID";
            this.Column2.Name = "Column2";
            // 
            // bANKBindingSource
            // 
            this.bANKBindingSource.DataMember = "BANK";
            this.bANKBindingSource.DataSource = this.z1DataSet;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(96, 162);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(112, 23);
            this.button5.TabIndex = 11;
            this.button5.Text = "Очистить поля";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(9, 162);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 10;
            this.button4.Text = "Записать";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(100, 133);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(646, 20);
            this.textBox9.TabIndex = 9;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(78, 103);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(668, 20);
            this.textBox8.TabIndex = 8;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(79, 76);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(667, 20);
            this.textBox7.TabIndex = 7;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(78, 45);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(402, 20);
            this.textBox6.TabIndex = 6;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(79, 19);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(667, 20);
            this.textBox5.TabIndex = 5;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(14, 136);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(87, 13);
            this.label15.TabIndex = 4;
            this.label15.Text = "Дополнительно";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 110);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(38, 13);
            this.label14.TabIndex = 3;
            this.label14.Text = "Адрес";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(13, 79);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 13);
            this.label13.TabIndex = 2;
            this.label13.Text = "Отделение";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 49);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 13);
            this.label12.TabIndex = 1;
            this.label12.Text = "Счет";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "Название";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1070, 729);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Сотрудники";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBox23);
            this.groupBox6.Controls.Add(this.label35);
            this.groupBox6.Controls.Add(this.button2);
            this.groupBox6.Controls.Add(this.dataGridView5);
            this.groupBox6.Controls.Add(this.button7);
            this.groupBox6.Controls.Add(this.button6);
            this.groupBox6.Controls.Add(this.textBox11);
            this.groupBox6.Controls.Add(this.textBox10);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Location = new System.Drawing.Point(9, 10);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(822, 113);
            this.groupBox6.TabIndex = 4;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Должности";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(595, 75);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(50, 20);
            this.textBox23.TabIndex = 9;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(548, 78);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(24, 13);
            this.label35.TabIndex = 8;
            this.label35.Text = "ИД";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(207, 81);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(132, 23);
            this.button2.TabIndex = 7;
            this.button2.Text = "Удалить строку";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // dataGridView5
            // 
            this.dataGridView5.AllowUserToAddRows = false;
            this.dataGridView5.AutoGenerateColumns = false;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nazvDataGridViewTextBoxColumn2,
            this.dop,
            this.idDataGridViewTextBoxColumn});
            this.dataGridView5.DataSource = this.bindingDOLG;
            this.dataGridView5.Location = new System.Drawing.Point(651, 14);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.Size = new System.Drawing.Size(168, 98);
            this.dataGridView5.TabIndex = 6;
            this.dataGridView5.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView5_CellClick);
            // 
            // nazvDataGridViewTextBoxColumn2
            // 
            this.nazvDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.nazvDataGridViewTextBoxColumn2.DataPropertyName = "nazv";
            this.nazvDataGridViewTextBoxColumn2.HeaderText = "ДОЛЖНОСТЬ";
            this.nazvDataGridViewTextBoxColumn2.Name = "nazvDataGridViewTextBoxColumn2";
            this.nazvDataGridViewTextBoxColumn2.Width = 105;
            // 
            // dop
            // 
            this.dop.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dop.DataPropertyName = "dop";
            this.dop.HeaderText = "ДОП";
            this.dop.Name = "dop";
            this.dop.Width = 57;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.HeaderText = "ИД";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.Width = 49;
            // 
            // bindingDOLG
            // 
            this.bindingDOLG.DataMember = "DOLG";
            this.bindingDOLG.DataSource = this.z1DataSet;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(91, 81);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(110, 23);
            this.button7.TabIndex = 5;
            this.button7.Text = "Очистить поля";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(10, 81);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 4;
            this.button6.Text = "Записать";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(82, 49);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(562, 20);
            this.textBox11.TabIndex = 3;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(82, 19);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(562, 20);
            this.textBox10.TabIndex = 2;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 52);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 13);
            this.label17.TabIndex = 1;
            this.label17.Text = "Примечание";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(8, 22);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Название";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Controls.Add(this.textBox18);
            this.groupBox4.Controls.Add(this.button15);
            this.groupBox4.Controls.Add(this.dataGridView7);
            this.groupBox4.Controls.Add(this.comboBox6);
            this.groupBox4.Controls.Add(this.button9);
            this.groupBox4.Controls.Add(this.button8);
            this.groupBox4.Controls.Add(this.comboBox2);
            this.groupBox4.Controls.Add(this.textBox14);
            this.groupBox4.Controls.Add(this.textBox13);
            this.groupBox4.Controls.Add(this.textBox12);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Location = new System.Drawing.Point(9, 129);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(826, 616);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Сотрудники";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(672, 119);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(18, 13);
            this.label30.TabIndex = 15;
            this.label30.Text = "ID";
            // 
            // textBox18
            // 
            this.textBox18.Enabled = false;
            this.textBox18.Location = new System.Drawing.Point(719, 116);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(100, 20);
            this.textBox18.TabIndex = 14;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(206, 151);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(120, 22);
            this.button15.TabIndex = 13;
            this.button15.Text = "Удалить запись";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // dataGridView7
            // 
            this.dataGridView7.AllowUserToAddRows = false;
            this.dataGridView7.AllowUserToDeleteRows = false;
            this.dataGridView7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView7.AutoGenerateColumns = false;
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.fioDataGridViewTextBoxColumn2,
            this.phoneDataGridViewTextBoxColumn2,
            this.adrDataGridViewTextBoxColumn4,
            this.iddolg1DataGridViewTextBoxColumn1,
            this.idkontrDataGridViewTextBoxColumn2,
            this.idDataGridViewTextBoxColumn4,
            this.nazv});
            this.dataGridView7.DataSource = this.pEOPLEBindingSource1;
            this.dataGridView7.Location = new System.Drawing.Point(9, 180);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.Size = new System.Drawing.Size(810, 430);
            this.dataGridView7.TabIndex = 12;
            this.dataGridView7.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView7_CellContentClick);
            this.dataGridView7.Click += new System.EventHandler(this.dataGridView7_Click);
            // 
            // fioDataGridViewTextBoxColumn2
            // 
            this.fioDataGridViewTextBoxColumn2.DataPropertyName = "fio";
            this.fioDataGridViewTextBoxColumn2.HeaderText = "ФИО";
            this.fioDataGridViewTextBoxColumn2.Name = "fioDataGridViewTextBoxColumn2";
            // 
            // phoneDataGridViewTextBoxColumn2
            // 
            this.phoneDataGridViewTextBoxColumn2.DataPropertyName = "phone";
            this.phoneDataGridViewTextBoxColumn2.HeaderText = "ТЕЛЕФОН";
            this.phoneDataGridViewTextBoxColumn2.Name = "phoneDataGridViewTextBoxColumn2";
            // 
            // adrDataGridViewTextBoxColumn4
            // 
            this.adrDataGridViewTextBoxColumn4.DataPropertyName = "adr";
            this.adrDataGridViewTextBoxColumn4.HeaderText = "АДРЕС";
            this.adrDataGridViewTextBoxColumn4.Name = "adrDataGridViewTextBoxColumn4";
            // 
            // iddolg1DataGridViewTextBoxColumn1
            // 
            this.iddolg1DataGridViewTextBoxColumn1.DataPropertyName = "id_dolg1";
            this.iddolg1DataGridViewTextBoxColumn1.HeaderText = "Должность";
            this.iddolg1DataGridViewTextBoxColumn1.Name = "iddolg1DataGridViewTextBoxColumn1";
            // 
            // idkontrDataGridViewTextBoxColumn2
            // 
            this.idkontrDataGridViewTextBoxColumn2.DataPropertyName = "id_kontr";
            this.idkontrDataGridViewTextBoxColumn2.HeaderText = "КОНТРАГЕНТ";
            this.idkontrDataGridViewTextBoxColumn2.Name = "idkontrDataGridViewTextBoxColumn2";
            this.idkontrDataGridViewTextBoxColumn2.Visible = false;
            // 
            // idDataGridViewTextBoxColumn4
            // 
            this.idDataGridViewTextBoxColumn4.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn4.HeaderText = "ID";
            this.idDataGridViewTextBoxColumn4.Name = "idDataGridViewTextBoxColumn4";
            // 
            // nazv
            // 
            this.nazv.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.nazv.DataPropertyName = "nazv";
            this.nazv.HeaderText = "КОНТРАГЕНТ";
            this.nazv.Name = "nazv";
            this.nazv.Width = 104;
            // 
            // pEOPLEBindingSource1
            // 
            this.pEOPLEBindingSource1.DataMember = "PEOPLE";
            this.pEOPLEBindingSource1.DataSource = this.z1DataSet;
            // 
            // comboBox6
            // 
            this.comboBox6.DataSource = this.kONTRBindingSource;
            this.comboBox6.DisplayMember = "nazv";
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(90, 43);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(730, 21);
            this.comboBox6.TabIndex = 11;
            this.comboBox6.ValueMember = "id";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(91, 151);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(110, 23);
            this.button9.TabIndex = 10;
            this.button9.Text = "Очистить поля";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(10, 151);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 9;
            this.button8.Text = "Записать";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.bindingDOLG;
            this.comboBox2.DisplayMember = "nazv";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(90, 115);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(372, 21);
            this.comboBox2.TabIndex = 8;
            this.comboBox2.ValueMember = "id";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(91, 89);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(729, 20);
            this.textBox14.TabIndex = 7;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(91, 67);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(729, 20);
            this.textBox13.TabIndex = 6;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(91, 22);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(729, 20);
            this.textBox12.TabIndex = 5;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(9, 118);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 13);
            this.label22.TabIndex = 4;
            this.label22.Text = "Должность";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(9, 92);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(38, 13);
            this.label21.TabIndex = 3;
            this.label21.Text = "Адрес";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(9, 70);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(52, 13);
            this.label20.TabIndex = 2;
            this.label20.Text = "Телефон";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(11, 46);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 13);
            this.label19.TabIndex = 1;
            this.label19.Text = "Контрагент";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(11, 25);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(34, 13);
            this.label18.TabIndex = 0;
            this.label18.Text = "ФИО";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox2);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1070, 729);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Контрагенты";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.button16);
            this.groupBox2.Controls.Add(this.dataGridView8);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(759, 744);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Контрагенты";
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(214, 154);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(112, 23);
            this.button16.TabIndex = 13;
            this.button16.Text = "Удалить строку";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // dataGridView8
            // 
            this.dataGridView8.AllowUserToAddRows = false;
            this.dataGridView8.AllowUserToDeleteRows = false;
            this.dataGridView8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView8.AutoGenerateColumns = false;
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.unnDataGridViewTextBoxColumn1,
            this.nazvDataGridViewTextBoxColumn5,
            this.uadrDataGridViewTextBoxColumn1,
            this.padrDataGridViewTextBoxColumn1,
            this.b,
            this.idDataGridViewTextBoxColumn5});
            this.dataGridView8.DataSource = this.kONTRBindingSource;
            this.dataGridView8.Location = new System.Drawing.Point(2, 183);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.Size = new System.Drawing.Size(751, 555);
            this.dataGridView8.TabIndex = 12;
            this.dataGridView8.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView8_CellClick);
            this.dataGridView8.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView8_CellContentClick);
            // 
            // unnDataGridViewTextBoxColumn1
            // 
            this.unnDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.unnDataGridViewTextBoxColumn1.DataPropertyName = "unn";
            this.unnDataGridViewTextBoxColumn1.HeaderText = "УНП";
            this.unnDataGridViewTextBoxColumn1.Name = "unnDataGridViewTextBoxColumn1";
            this.unnDataGridViewTextBoxColumn1.Width = 56;
            // 
            // nazvDataGridViewTextBoxColumn5
            // 
            this.nazvDataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.nazvDataGridViewTextBoxColumn5.DataPropertyName = "nazv";
            this.nazvDataGridViewTextBoxColumn5.HeaderText = "НАЗВАНИЕ";
            this.nazvDataGridViewTextBoxColumn5.Name = "nazvDataGridViewTextBoxColumn5";
            this.nazvDataGridViewTextBoxColumn5.Width = 91;
            // 
            // uadrDataGridViewTextBoxColumn1
            // 
            this.uadrDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.uadrDataGridViewTextBoxColumn1.DataPropertyName = "uadr";
            this.uadrDataGridViewTextBoxColumn1.HeaderText = "ЮР АДРЕС";
            this.uadrDataGridViewTextBoxColumn1.Name = "uadrDataGridViewTextBoxColumn1";
            this.uadrDataGridViewTextBoxColumn1.Width = 81;
            // 
            // padrDataGridViewTextBoxColumn1
            // 
            this.padrDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.padrDataGridViewTextBoxColumn1.DataPropertyName = "padr";
            this.padrDataGridViewTextBoxColumn1.HeaderText = "ПОЧТ АДРЕС";
            this.padrDataGridViewTextBoxColumn1.Name = "padrDataGridViewTextBoxColumn1";
            this.padrDataGridViewTextBoxColumn1.Width = 95;
            // 
            // b
            // 
            this.b.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.b.DataPropertyName = "b";
            this.b.HeaderText = "БАНК";
            this.b.Name = "b";
            this.b.Width = 61;
            // 
            // idDataGridViewTextBoxColumn5
            // 
            this.idDataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.idDataGridViewTextBoxColumn5.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn5.HeaderText = "ID";
            this.idDataGridViewTextBoxColumn5.Name = "idDataGridViewTextBoxColumn5";
            this.idDataGridViewTextBoxColumn5.Width = 5;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(96, 154);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 23);
            this.button3.TabIndex = 11;
            this.button3.Text = "Очистить поля";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(10, 154);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "Записать";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.bANKBindingSource1;
            this.comboBox1.DisplayMember = "dop";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(44, 116);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(702, 21);
            this.comboBox1.TabIndex = 9;
            this.comboBox1.ValueMember = "id";
            // 
            // bANKBindingSource1
            // 
            this.bANKBindingSource1.DataMember = "BANK";
            this.bANKBindingSource1.DataSource = this.z1DataSet;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(79, 84);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(667, 20);
            this.textBox4.TabIndex = 8;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(70, 52);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(676, 20);
            this.textBox3.TabIndex = 7;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(237, 20);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(509, 20);
            this.textBox2.TabIndex = 6;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(59, 20);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 119);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(32, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "Банк";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 87);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Почт. адрес";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 55);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Юр. адрес";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(174, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Название";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "УНН";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dataGridView10);
            this.tabPage4.Controls.Add(this.groupBox7);
            this.tabPage4.Controls.Add(this.groupBox5);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1070, 729);
            this.tabPage4.TabIndex = 5;
            this.tabPage4.Text = "Договоры";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dataGridView10
            // 
            this.dataGridView10.AllowUserToAddRows = false;
            this.dataGridView10.AllowUserToDeleteRows = false;
            this.dataGridView10.AutoGenerateColumns = false;
            this.dataGridView10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView10.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn7,
            this.nazvDataGridViewTextBoxColumn7});
            this.dataGridView10.DataSource = this.sTATUSBindingSource;
            this.dataGridView10.Location = new System.Drawing.Point(482, 15);
            this.dataGridView10.Name = "dataGridView10";
            this.dataGridView10.ReadOnly = true;
            this.dataGridView10.Size = new System.Drawing.Size(438, 75);
            this.dataGridView10.TabIndex = 6;
            this.dataGridView10.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView10_CellClick);
            // 
            // idDataGridViewTextBoxColumn7
            // 
            this.idDataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.idDataGridViewTextBoxColumn7.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn7.HeaderText = "ID";
            this.idDataGridViewTextBoxColumn7.Name = "idDataGridViewTextBoxColumn7";
            this.idDataGridViewTextBoxColumn7.ReadOnly = true;
            this.idDataGridViewTextBoxColumn7.Width = 43;
            // 
            // nazvDataGridViewTextBoxColumn7
            // 
            this.nazvDataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.nazvDataGridViewTextBoxColumn7.DataPropertyName = "nazv";
            this.nazvDataGridViewTextBoxColumn7.HeaderText = "СТАТУС";
            this.nazvDataGridViewTextBoxColumn7.Name = "nazvDataGridViewTextBoxColumn7";
            this.nazvDataGridViewTextBoxColumn7.ReadOnly = true;
            this.nazvDataGridViewTextBoxColumn7.Width = 75;
            // 
            // sTATUSBindingSource
            // 
            this.sTATUSBindingSource.DataMember = "STATUS";
            this.sTATUSBindingSource.DataSource = this.z1DataSet;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.button18);
            this.groupBox7.Controls.Add(this.textBox15);
            this.groupBox7.Controls.Add(this.label23);
            this.groupBox7.Controls.Add(this.button11);
            this.groupBox7.Controls.Add(this.button10);
            this.groupBox7.Location = new System.Drawing.Point(7, 9);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(469, 82);
            this.groupBox7.TabIndex = 5;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Статусы";
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(227, 52);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(123, 23);
            this.button18.TabIndex = 4;
            this.button18.Text = "Удалить строку";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(56, 21);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(407, 20);
            this.textBox15.TabIndex = 3;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(9, 24);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 13);
            this.label23.TabIndex = 2;
            this.label23.Text = "Статус";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(97, 51);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(124, 23);
            this.button11.TabIndex = 1;
            this.button11.Text = "Очистить поля";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(6, 51);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(85, 24);
            this.button10.TabIndex = 0;
            this.button10.Text = "Записать";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.textBox19);
            this.groupBox5.Controls.Add(this.label31);
            this.groupBox5.Controls.Add(this.button17);
            this.groupBox5.Controls.Add(this.dataGridView9);
            this.groupBox5.Controls.Add(this.comboBox5);
            this.groupBox5.Controls.Add(this.comboBox4);
            this.groupBox5.Controls.Add(this.button13);
            this.groupBox5.Controls.Add(this.button12);
            this.groupBox5.Controls.Add(this.comboBox3);
            this.groupBox5.Controls.Add(this.dateTimePicker2);
            this.groupBox5.Controls.Add(this.dateTimePicker1);
            this.groupBox5.Controls.Add(this.textBox16);
            this.groupBox5.Controls.Add(this.label29);
            this.groupBox5.Controls.Add(this.label28);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Location = new System.Drawing.Point(7, 97);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1060, 653);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Договоры";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(572, 103);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(59, 20);
            this.textBox19.TabIndex = 19;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(548, 106);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(18, 13);
            this.label31.TabIndex = 18;
            this.label31.Text = "ID";
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(227, 197);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(123, 23);
            this.button17.TabIndex = 17;
            this.button17.Text = "Удалить строку";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // dataGridView9
            // 
            this.dataGridView9.AllowUserToAddRows = false;
            this.dataGridView9.AllowUserToDeleteRows = false;
            this.dataGridView9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView9.AutoGenerateColumns = false;
            this.dataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView9.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nomer,
            this.stsDataGridViewTextBoxColumn,
            this.НАЧАЛО,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.fio,
            this.id});
            this.dataGridView9.DataSource = this.dOGOVORBindingSourcedogovor;
            this.dataGridView9.Location = new System.Drawing.Point(6, 226);
            this.dataGridView9.Name = "dataGridView9";
            this.dataGridView9.Size = new System.Drawing.Size(1048, 424);
            this.dataGridView9.TabIndex = 16;
            this.dataGridView9.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView9_CellClick);
            this.dataGridView9.Click += new System.EventHandler(this.dataGridView9_Click);
            // 
            // dOGOVORBindingSourcedogovor
            // 
            this.dOGOVORBindingSourcedogovor.DataMember = "DOGOVOR";
            this.dOGOVORBindingSourcedogovor.DataSource = this.z1DataSet;
            // 
            // comboBox5
            // 
            this.comboBox5.DataSource = this.pEOPLEBindingSource;
            this.comboBox5.DisplayMember = "fio";
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(96, 78);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(535, 21);
            this.comboBox5.TabIndex = 15;
            this.comboBox5.ValueMember = "id";
            // 
            // pEOPLEBindingSource
            // 
            this.pEOPLEBindingSource.DataMember = "PEOPLE";
            this.pEOPLEBindingSource.DataSource = this.z1DataSet;
            // 
            // comboBox4
            // 
            this.comboBox4.DataSource = this.kONTRBindingSource;
            this.comboBox4.DisplayMember = "nazv";
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(96, 50);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(533, 21);
            this.comboBox4.TabIndex = 14;
            this.comboBox4.ValueMember = "id";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(96, 197);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(125, 23);
            this.button13.TabIndex = 13;
            this.button13.Text = "Очистить поля";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(6, 197);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(85, 23);
            this.button12.TabIndex = 12;
            this.button12.Text = "Записать";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.DataSource = this.sTATUSBindingSource;
            this.comboBox3.DisplayMember = "nazv";
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(98, 163);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(200, 21);
            this.comboBox3.TabIndex = 10;
            this.comboBox3.ValueMember = "id";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(98, 134);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker2.TabIndex = 9;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(96, 104);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(97, 24);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(534, 20);
            this.textBox16.TabIndex = 6;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(10, 166);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(41, 13);
            this.label29.TabIndex = 5;
            this.label29.Text = "Статус";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(10, 138);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(66, 13);
            this.label28.TabIndex = 4;
            this.label28.Text = "Дата конца";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(10, 110);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(71, 13);
            this.label27.TabIndex = 3;
            this.label27.Text = "Дата начала";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(10, 80);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(48, 13);
            this.label26.TabIndex = 2;
            this.label26.Text = "Куратор";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(10, 56);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(65, 13);
            this.label25.TabIndex = 1;
            this.label25.Text = "Контрагент";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(9, 27);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(41, 13);
            this.label24.TabIndex = 0;
            this.label24.Text = "Номер";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.groupBox10);
            this.tabPage6.Controls.Add(this.groupBox9);
            this.tabPage6.Controls.Add(this.groupBox8);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1070, 729);
            this.tabPage6.TabIndex = 6;
            this.tabPage6.Text = "Поиск";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.textBox22);
            this.groupBox10.Controls.Add(this.label34);
            this.groupBox10.Controls.Add(this.button24);
            this.groupBox10.Controls.Add(this.button23);
            this.groupBox10.Controls.Add(this.dataGridView13);
            this.groupBox10.Location = new System.Drawing.Point(6, 319);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(721, 196);
            this.groupBox10.TabIndex = 2;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Поиск сотрудника";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(79, 19);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(474, 20);
            this.textBox22.TabIndex = 4;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(4, 22);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(67, 13);
            this.label34.TabIndex = 3;
            this.label34.Text = "Что искать:";
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(640, 17);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(75, 23);
            this.button24.TabIndex = 2;
            this.button24.Text = "Очистить";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(559, 17);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(75, 23);
            this.button23.TabIndex = 1;
            this.button23.Text = "Искать";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // dataGridView13
            // 
            this.dataGridView13.AllowUserToAddRows = false;
            this.dataGridView13.AllowUserToDeleteRows = false;
            this.dataGridView13.AutoGenerateColumns = false;
            this.dataGridView13.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView13.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.fioDataGridViewTextBoxColumn4,
            this.phoneDataGridViewTextBoxColumn1,
            this.adrDataGridViewTextBoxColumn});
            this.dataGridView13.DataSource = this.pEOPLEBindingSource2;
            this.dataGridView13.Location = new System.Drawing.Point(7, 45);
            this.dataGridView13.Name = "dataGridView13";
            this.dataGridView13.ReadOnly = true;
            this.dataGridView13.Size = new System.Drawing.Size(708, 145);
            this.dataGridView13.TabIndex = 0;
            // 
            // fioDataGridViewTextBoxColumn4
            // 
            this.fioDataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.fioDataGridViewTextBoxColumn4.DataPropertyName = "fio";
            this.fioDataGridViewTextBoxColumn4.HeaderText = "ФИО";
            this.fioDataGridViewTextBoxColumn4.Name = "fioDataGridViewTextBoxColumn4";
            this.fioDataGridViewTextBoxColumn4.ReadOnly = true;
            this.fioDataGridViewTextBoxColumn4.Width = 59;
            // 
            // phoneDataGridViewTextBoxColumn1
            // 
            this.phoneDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.phoneDataGridViewTextBoxColumn1.DataPropertyName = "phone";
            this.phoneDataGridViewTextBoxColumn1.HeaderText = "Телефон";
            this.phoneDataGridViewTextBoxColumn1.Name = "phoneDataGridViewTextBoxColumn1";
            this.phoneDataGridViewTextBoxColumn1.ReadOnly = true;
            this.phoneDataGridViewTextBoxColumn1.Width = 77;
            // 
            // adrDataGridViewTextBoxColumn
            // 
            this.adrDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.adrDataGridViewTextBoxColumn.DataPropertyName = "adr";
            this.adrDataGridViewTextBoxColumn.HeaderText = "Адрес";
            this.adrDataGridViewTextBoxColumn.Name = "adrDataGridViewTextBoxColumn";
            this.adrDataGridViewTextBoxColumn.ReadOnly = true;
            this.adrDataGridViewTextBoxColumn.Width = 63;
            // 
            // pEOPLEBindingSource2
            // 
            this.pEOPLEBindingSource2.DataMember = "PEOPLE";
            this.pEOPLEBindingSource2.DataSource = this.z1DataSet;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.textBox21);
            this.groupBox9.Controls.Add(this.label33);
            this.groupBox9.Controls.Add(this.button22);
            this.groupBox9.Controls.Add(this.button21);
            this.groupBox9.Controls.Add(this.dataGridView12);
            this.groupBox9.Location = new System.Drawing.Point(6, 159);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(721, 154);
            this.groupBox9.TabIndex = 1;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Поиск договора";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(79, 19);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(474, 20);
            this.textBox21.TabIndex = 4;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(4, 22);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(67, 13);
            this.label33.TabIndex = 3;
            this.label33.Text = "Что искать:";
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(640, 17);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(75, 23);
            this.button22.TabIndex = 2;
            this.button22.Text = "Очистить";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(559, 17);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(75, 23);
            this.button21.TabIndex = 1;
            this.button21.Text = "Искать";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // dataGridView12
            // 
            this.dataGridView12.AllowUserToAddRows = false;
            this.dataGridView12.AllowUserToDeleteRows = false;
            this.dataGridView12.AutoGenerateColumns = false;
            this.dataGridView12.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView12.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nomerDataGridViewTextBoxColumn1,
            this.datebDataGridViewTextBoxColumn1,
            this.dateeDataGridViewTextBoxColumn1,
            this.statusDataGridViewTextBoxColumn,
            this.idkontrDataGridViewTextBoxColumn1,
            this.idpeopleDataGridViewTextBoxColumn1,
            this.idDataGridViewTextBoxColumn3});
            this.dataGridView12.DataSource = this.dOGOVORBindingSourcedogovor;
            this.dataGridView12.Location = new System.Drawing.Point(7, 45);
            this.dataGridView12.Name = "dataGridView12";
            this.dataGridView12.ReadOnly = true;
            this.dataGridView12.Size = new System.Drawing.Size(708, 103);
            this.dataGridView12.TabIndex = 0;
            // 
            // nomerDataGridViewTextBoxColumn1
            // 
            this.nomerDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.nomerDataGridViewTextBoxColumn1.DataPropertyName = "nomer";
            this.nomerDataGridViewTextBoxColumn1.HeaderText = "Номер";
            this.nomerDataGridViewTextBoxColumn1.Name = "nomerDataGridViewTextBoxColumn1";
            this.nomerDataGridViewTextBoxColumn1.ReadOnly = true;
            this.nomerDataGridViewTextBoxColumn1.Width = 66;
            // 
            // datebDataGridViewTextBoxColumn1
            // 
            this.datebDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.datebDataGridViewTextBoxColumn1.DataPropertyName = "date_b";
            this.datebDataGridViewTextBoxColumn1.HeaderText = "Начало";
            this.datebDataGridViewTextBoxColumn1.Name = "datebDataGridViewTextBoxColumn1";
            this.datebDataGridViewTextBoxColumn1.ReadOnly = true;
            this.datebDataGridViewTextBoxColumn1.Width = 69;
            // 
            // dateeDataGridViewTextBoxColumn1
            // 
            this.dateeDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dateeDataGridViewTextBoxColumn1.DataPropertyName = "date_e";
            this.dateeDataGridViewTextBoxColumn1.HeaderText = "Конец";
            this.dateeDataGridViewTextBoxColumn1.Name = "dateeDataGridViewTextBoxColumn1";
            this.dateeDataGridViewTextBoxColumn1.ReadOnly = true;
            this.dateeDataGridViewTextBoxColumn1.Width = 63;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Статус";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.ReadOnly = true;
            this.statusDataGridViewTextBoxColumn.Width = 66;
            // 
            // idkontrDataGridViewTextBoxColumn1
            // 
            this.idkontrDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.idkontrDataGridViewTextBoxColumn1.DataPropertyName = "id_kontr";
            this.idkontrDataGridViewTextBoxColumn1.HeaderText = "Контрагент";
            this.idkontrDataGridViewTextBoxColumn1.Name = "idkontrDataGridViewTextBoxColumn1";
            this.idkontrDataGridViewTextBoxColumn1.ReadOnly = true;
            this.idkontrDataGridViewTextBoxColumn1.Width = 90;
            // 
            // idpeopleDataGridViewTextBoxColumn1
            // 
            this.idpeopleDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.idpeopleDataGridViewTextBoxColumn1.DataPropertyName = "id_people";
            this.idpeopleDataGridViewTextBoxColumn1.HeaderText = "Куратор";
            this.idpeopleDataGridViewTextBoxColumn1.Name = "idpeopleDataGridViewTextBoxColumn1";
            this.idpeopleDataGridViewTextBoxColumn1.ReadOnly = true;
            this.idpeopleDataGridViewTextBoxColumn1.Width = 73;
            // 
            // idDataGridViewTextBoxColumn3
            // 
            this.idDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.idDataGridViewTextBoxColumn3.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn3.HeaderText = "ИД";
            this.idDataGridViewTextBoxColumn3.Name = "idDataGridViewTextBoxColumn3";
            this.idDataGridViewTextBoxColumn3.ReadOnly = true;
            this.idDataGridViewTextBoxColumn3.Width = 49;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.textBox20);
            this.groupBox8.Controls.Add(this.label32);
            this.groupBox8.Controls.Add(this.button20);
            this.groupBox8.Controls.Add(this.button19);
            this.groupBox8.Controls.Add(this.dataGridView11);
            this.groupBox8.Location = new System.Drawing.Point(6, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(721, 147);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Поиск контрагента";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(79, 18);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(474, 20);
            this.textBox20.TabIndex = 4;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(4, 21);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(67, 13);
            this.label32.TabIndex = 3;
            this.label32.Text = "Что искать:";
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(640, 16);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(75, 23);
            this.button20.TabIndex = 2;
            this.button20.Text = "Очистить";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(559, 16);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(75, 23);
            this.button19.TabIndex = 1;
            this.button19.Text = "Искать";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // dataGridView11
            // 
            this.dataGridView11.AllowUserToAddRows = false;
            this.dataGridView11.AllowUserToDeleteRows = false;
            this.dataGridView11.AutoGenerateColumns = false;
            this.dataGridView11.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView11.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.unnDataGridViewTextBoxColumn2,
            this.nazvDataGridViewTextBoxColumn6,
            this.uadrDataGridViewTextBoxColumn2,
            this.padrDataGridViewTextBoxColumn2});
            this.dataGridView11.DataSource = this.kONTRBindingSource;
            this.dataGridView11.Location = new System.Drawing.Point(7, 44);
            this.dataGridView11.Name = "dataGridView11";
            this.dataGridView11.ReadOnly = true;
            this.dataGridView11.Size = new System.Drawing.Size(708, 97);
            this.dataGridView11.TabIndex = 0;
            // 
            // unnDataGridViewTextBoxColumn2
            // 
            this.unnDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.unnDataGridViewTextBoxColumn2.DataPropertyName = "unn";
            this.unnDataGridViewTextBoxColumn2.HeaderText = "УНН";
            this.unnDataGridViewTextBoxColumn2.Name = "unnDataGridViewTextBoxColumn2";
            this.unnDataGridViewTextBoxColumn2.ReadOnly = true;
            this.unnDataGridViewTextBoxColumn2.Width = 56;
            // 
            // nazvDataGridViewTextBoxColumn6
            // 
            this.nazvDataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.nazvDataGridViewTextBoxColumn6.DataPropertyName = "nazv";
            this.nazvDataGridViewTextBoxColumn6.HeaderText = "Название";
            this.nazvDataGridViewTextBoxColumn6.Name = "nazvDataGridViewTextBoxColumn6";
            this.nazvDataGridViewTextBoxColumn6.ReadOnly = true;
            this.nazvDataGridViewTextBoxColumn6.Width = 82;
            // 
            // uadrDataGridViewTextBoxColumn2
            // 
            this.uadrDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.uadrDataGridViewTextBoxColumn2.DataPropertyName = "uadr";
            this.uadrDataGridViewTextBoxColumn2.HeaderText = "Юр. адрес";
            this.uadrDataGridViewTextBoxColumn2.Name = "uadrDataGridViewTextBoxColumn2";
            this.uadrDataGridViewTextBoxColumn2.ReadOnly = true;
            this.uadrDataGridViewTextBoxColumn2.Width = 83;
            // 
            // padrDataGridViewTextBoxColumn2
            // 
            this.padrDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.padrDataGridViewTextBoxColumn2.DataPropertyName = "padr";
            this.padrDataGridViewTextBoxColumn2.HeaderText = "Почт. адрес";
            this.padrDataGridViewTextBoxColumn2.Name = "padrDataGridViewTextBoxColumn2";
            this.padrDataGridViewTextBoxColumn2.ReadOnly = true;
            this.padrDataGridViewTextBoxColumn2.Width = 92;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.reportViewer2);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1070, 729);
            this.tabPage7.TabIndex = 7;
            this.tabPage7.Text = "Отчет";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // reportViewer2
            // 
            this.reportViewer2.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.ZdogBindingSource;
            this.reportViewer2.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer2.LocalReport.ReportEmbeddedResource = "KONTRAGENT.Report3.rdlc";
            this.reportViewer2.Location = new System.Drawing.Point(3, 3);
            this.reportViewer2.Name = "reportViewer2";
            this.reportViewer2.Size = new System.Drawing.Size(1064, 723);
            this.reportViewer2.TabIndex = 0;
            // 
            // pEOPLEDOLGBindingSource
            // 
            this.pEOPLEDOLGBindingSource.DataMember = "PEOPLEDOLG";
            this.pEOPLEDOLGBindingSource.DataSource = this.pEOPLEBindingSource1;
            // 
            // dOGOVORBindingSource
            // 
            this.dOGOVORBindingSource.DataMember = "DOGOVOR";
            this.dOGOVORBindingSource.DataSource = this.z1DataSet;
            // 
            // bANKKONTRBindingSource
            // 
            this.bANKKONTRBindingSource.DataMember = "BANKKONTR";
            this.bANKKONTRBindingSource.DataSource = this.kONTRBindingSource;
            // 
            // kONTRTableAdapter
            // 
            this.kONTRTableAdapter.ClearBeforeFill = true;
            // 
            // bANKTableAdapter
            // 
            this.bANKTableAdapter.ClearBeforeFill = true;
            // 
            // pEOPLETableAdapter
            // 
            this.pEOPLETableAdapter.ClearBeforeFill = true;
            // 
            // dOGOVORTableAdapter
            // 
            this.dOGOVORTableAdapter.ClearBeforeFill = true;
            // 
            // dOLGTableAdapter
            // 
            this.dOLGTableAdapter.ClearBeforeFill = true;
            // 
            // sTATUSTableAdapter
            // 
            this.sTATUSTableAdapter.ClearBeforeFill = true;
            // 
            // helpProvider1
            // 
            this.helpProvider1.HelpNamespace = "KONTRAGENT.chm";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.фАЙЛToolStripMenuItem,
            this.помощьToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1078, 24);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // фАЙЛToolStripMenuItem
            // 
            this.фАЙЛToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вЫХОДToolStripMenuItem});
            this.фАЙЛToolStripMenuItem.Name = "фАЙЛToolStripMenuItem";
            this.фАЙЛToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.фАЙЛToolStripMenuItem.Text = "ФАЙЛ";
            // 
            // вЫХОДToolStripMenuItem
            // 
            this.вЫХОДToolStripMenuItem.Name = "вЫХОДToolStripMenuItem";
            this.вЫХОДToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.вЫХОДToolStripMenuItem.Text = "ВЫХОД";
            this.вЫХОДToolStripMenuItem.Click += new System.EventHandler(this.вЫХОДToolStripMenuItem_Click);
            // 
            // помощьToolStripMenuItem
            // 
            this.помощьToolStripMenuItem.Name = "помощьToolStripMenuItem";
            this.помощьToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.помощьToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.помощьToolStripMenuItem.Text = "ПОМОЩЬ";
            this.помощьToolStripMenuItem.Click += new System.EventHandler(this.помощьToolStripMenuItem_Click);
            // 
            // ZdogTableAdapter
            // 
            this.ZdogTableAdapter.ClearBeforeFill = true;
            // 
            // nomer
            // 
            this.nomer.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.nomer.DataPropertyName = "nomer";
            this.nomer.HeaderText = "НАЗВАНИЕ";
            this.nomer.Name = "nomer";
            this.nomer.Width = 91;
            // 
            // stsDataGridViewTextBoxColumn
            // 
            this.stsDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.stsDataGridViewTextBoxColumn.DataPropertyName = "sts";
            this.stsDataGridViewTextBoxColumn.HeaderText = "СТАТУС";
            this.stsDataGridViewTextBoxColumn.Name = "stsDataGridViewTextBoxColumn";
            this.stsDataGridViewTextBoxColumn.Width = 75;
            // 
            // НАЧАЛО
            // 
            this.НАЧАЛО.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.НАЧАЛО.DataPropertyName = "date_b";
            this.НАЧАЛО.HeaderText = "НАЧАЛО";
            this.НАЧАЛО.Name = "НАЧАЛО";
            this.НАЧАЛО.Width = 78;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "date_e";
            this.dataGridViewTextBoxColumn1.HeaderText = "КОНЕЦ";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 70;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "nazv";
            this.dataGridViewTextBoxColumn2.HeaderText = "КОНТРАГЕНТ";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 104;
            // 
            // fio
            // 
            this.fio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.fio.DataPropertyName = "fio";
            this.fio.HeaderText = "КУРАТОР";
            this.fio.Name = "fio";
            this.fio.Width = 83;
            // 
            // id
            // 
            this.id.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "ИД";
            this.id.Name = "id";
            this.id.Width = 49;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1078, 779);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.helpProvider1.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Index);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.helpProvider1.SetShowHelp(this, true);
            this.Text = "Справочник контрагентов организации Верхов ПО-455";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ZdogBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.z1DataSet)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kONTRPEOPLEBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kONTRBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kONTRDOGOVORBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bANKKONTRBindingSource1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bANKBindingSource)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingDOLG)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pEOPLEBindingSource1)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bANKBindingSource1)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sTATUSBindingSource)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dOGOVORBindingSourcedogovor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pEOPLEBindingSource)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pEOPLEBindingSource2)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView12)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).EndInit();
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pEOPLEDOLGBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dOGOVORBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bANKKONTRBindingSource)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textBox16;
        private Z1DataSet z1DataSet;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox6;
#pragma warning disable CS0169 // Поле "Form1.dOLGPEOPLEBindingSource" никогда не используется.
        private System.Windows.Forms.BindingSource dOLGPEOPLEBindingSource;
#pragma warning restore CS0169 // Поле "Form1.dOLGPEOPLEBindingSource" никогда не используется.
#pragma warning disable CS0169 // Поле "Form1.dOLGPEOPLEBindingSource1" никогда не используется.
        private System.Windows.Forms.BindingSource dOLGPEOPLEBindingSource1;
#pragma warning restore CS0169 // Поле "Form1.dOLGPEOPLEBindingSource1" никогда не используется.
#pragma warning disable CS0169 // Поле "Form1.dOLGPEOPLEBindingSource2" никогда не используется.
        private System.Windows.Forms.BindingSource dOLGPEOPLEBindingSource2;
#pragma warning restore CS0169 // Поле "Form1.dOLGPEOPLEBindingSource2" никогда не используется.
#pragma warning disable CS0169 // Поле "Form1.dOLGBindingSource" никогда не используется.
        private System.Windows.Forms.BindingSource dOLGBindingSource;
#pragma warning restore CS0169 // Поле "Form1.dOLGBindingSource" никогда не используется.
#pragma warning disable CS0169 // Поле "Form1.dOLGPEOPBindingSource" никогда не используется.
        private System.Windows.Forms.BindingSource dOLGPEOPBindingSource;
#pragma warning restore CS0169 // Поле "Form1.dOLGPEOPBindingSource" никогда не используется.
#pragma warning disable CS0169 // Поле "Form1.dOLGPEOPLE2BindingSource" никогда не используется.
        private System.Windows.Forms.BindingSource dOLGPEOPLE2BindingSource;
#pragma warning restore CS0169 // Поле "Form1.dOLGPEOPLE2BindingSource" никогда не используется.
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.BindingSource kONTRBindingSource;
        private Z1DataSetTableAdapters.KONTRTableAdapter kONTRTableAdapter;
        private System.Windows.Forms.BindingSource bANKKONTRBindingSource;
        private Z1DataSetTableAdapters.BANKTableAdapter bANKTableAdapter;
        private System.Windows.Forms.BindingSource kONTRPEOPLEBindingSource;
        private Z1DataSetTableAdapters.PEOPLETableAdapter pEOPLETableAdapter;
        private Z1DataSetTableAdapters.DOGOVORTableAdapter dOGOVORTableAdapter;
        private Z1DataSetTableAdapters.DOLGTableAdapter dOLGTableAdapter;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.BindingSource bANKBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazvDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn adrDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn schetDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn filialDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dopDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.BindingSource pEOPLEBindingSource;
        private System.Windows.Forms.BindingSource pEOPLEBindingSource1;
        private System.Windows.Forms.DataGridView dataGridView8;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.DataGridView dataGridView10;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.DataGridView dataGridView9;
        private System.Windows.Forms.BindingSource sTATUSBindingSource;
        private Z1DataSetTableAdapters.STATUSTableAdapter sTATUSTableAdapter;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.HelpProvider helpProvider1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem фАЙЛToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вЫХОДToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem помощьToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage7;
#pragma warning disable CS0169 // Поле "Form1.reportViewer1" никогда не используется.
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
#pragma warning restore CS0169 // Поле "Form1.reportViewer1" никогда не используется.
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.DataGridView dataGridView13;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.DataGridView dataGridView12;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.DataGridView dataGridView11;
        private System.Windows.Forms.BindingSource pEOPLEBindingSource2;
        private System.Windows.Forms.DataGridViewTextBoxColumn fioDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn adrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unnDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazvDataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn uadrDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn padrDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazvDataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn snazDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn knazDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fioDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn snazDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn knazDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn fioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adrDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iddolg1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazvDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn uadrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn padrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unnDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn schet;
        private System.Windows.Forms.DataGridViewTextBoxColumn filial;
        private System.Windows.Forms.DataGridViewTextBoxColumn adr;
        private System.Windows.Forms.BindingSource dOGOVORBindingSource;
        private System.Windows.Forms.BindingSource kONTRDOGOVORBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource bANKKONTRBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn date_b;
        private System.Windows.Forms.DataGridViewTextBoxColumn date_e;
        private System.Windows.Forms.BindingSource bindingDOLG;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datebDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn idkontrDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource pEOPLEDOLGBindingSource;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazvDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dop;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource bANKBindingSource1;
        private System.Windows.Forms.BindingSource dOGOVORBindingSourcedogovor;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomerDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn datebDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateeDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idkontrDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idpeopleDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn3;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer2;
        private System.Windows.Forms.BindingSource ZdogBindingSource;
        private Z1DataSetTableAdapters.ZdogTableAdapter ZdogTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn unnDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazvDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn uadrDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn padrDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn b;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn fioDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn adrDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn iddolg1DataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idkontrDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazv;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn stsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn НАЧАЛО;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn fio;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
    }
}


﻿namespace KONTRAGENT
{


    partial class Z1DataSet
    {
        partial class DOGOVORDataTable
        {
        }

        partial class PEOPLEDataTable
        {
        }

        partial class DataTable1DataTable
        {
        }

        partial class BANKDataTable
        {
        }
    }
}

namespace KONTRAGENT.Z1DataSetTableAdapters
{
    partial class STATUSTableAdapter
    {
    }

    partial class DOGOVORTableAdapter
    {
    }

    partial class PEOPLETableAdapter
    {
    }

    public partial class DOLGTableAdapter {
    }
}

﻿namespace AUTO
{


    partial class AUTODataSet
    {
    }
}

namespace AUTO.AUTODataSetTableAdapters {
    
    
    public partial class toplivoTableAdapter {
    }
}
